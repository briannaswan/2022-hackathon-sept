/* eslint-disable */
import { faker } from '@faker-js/faker';
import React from "react";
// @mui
import ElectricBoltIcon from '@mui/icons-material/ElectricBolt';
import { useTheme } from '@mui/material/styles';
import { Grid, Container, Typography } from '@mui/material';
import ROOM_PIC from './room.png';
// components
import Page from '../components/Page';
import Iconify from '../components/Iconify';
// sections
import PopUp from "./PopUp";
import {
  AppTasks,
  AppNewsUpdate,
  AppOrderTimeline,
  AppCurrentVisits,
  AppWebsiteVisits,
  AppTrafficBySite,
  AppWidgetSummary,
  AppCurrentSubject,
  AppConversionRates,
} from '../sections/@dashboard/app';

// ----------------------------------------------------------------------

export default function DashboardApp() {
  const theme = useTheme();

    const [seen, setSeen] = React.useState(false);
    const togglePop = () => {
        setSeen(!seen);
    };

    const handleClick = (event, message) => {
        // 👇️ refers to the image element
        console.log(event.target);

        console.log(message);

        console.log('Image clicked');
        togglePop();
    };


  return (
    <Page title="Dashboard">

        <div>

            {seen ? <PopUp toggle={togglePop} /> : null}
        </div>

        { !seen?<img style={{
            borderColor: "black",
            borderWidth: 200
        }}src={ROOM_PIC} alt={"Carlie Anglemire"} onClick={(event) => handleClick(event, 'hello')}/>:null


        }



        {seen?
      <Container maxWidth="xl">

        <Typography variant="h4" sx={{ mb: 5 }}>
          ROOM #1234
        </Typography>

          <Typography variant="h4" sx={{ mb: 4 }}>
              Device: PC #5678
          </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Power consumption" total={"200 Wh"} icon={"simple-line-icons:energy"} />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Carbon footprint" total={"47 gCO2e"} color="info" icon={'iwwa:co2'} />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Power-on hours" total={"13 hours"} color="warning" icon={'entypo:hour-glass'} />
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Usage Level" total={"Low"} color="error" icon={'carbon:warning'} />
          </Grid>

          <Grid item xs={12} md={6} lg={8}>
            <AppWebsiteVisits
              title="Power Consumption"
              subheader="(+43%) than last month"
              chartLabels={[
                '01/01/2003',
                '01/02/2003',
                '01/03/2003',
                '01/04/2003',
                '01/05/2003',
                '01/06/2003',
                '01/07/2003',
                '01/08/2003',
                '01/09/2003',
                '01/10/2003',
                '01/11/2003',
              ]}
              chartData={[
                {
                  name: 'PC #1234',
                  type: 'column',
                  fill: 'solid',
                  data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30],
                },

              ]}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={4}>
            <AppCurrentVisits
              title="On time"
              chartData={[
                { label: 'ON', value: 8 },
                { label: 'OFF', value: 16 },
              ]}
              chartColors={[
                theme.palette.primary.main,
                theme.palette.chart.blue[0],
                theme.palette.chart.violet[0],
                theme.palette.chart.yellow[0],
              ]}
            />
          </Grid>



          <Grid item xs={12} md={6} lg={8}>
            <AppNewsUpdate
              title="Warnings"
              list={[...Array(5)].map((_, index) => ({
                id: faker.datatype.uuid(),
                title: "Unusual activity",
                description: "PC #1234 is usually turned off at this hour. Do you want to turn it off?",
                image: null,
                postedAt: faker.date.recent(),
              }))}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={4}>
            <AppOrderTimeline
              title="Actions Timeline"
              list={[...Array(5)].map((_, index) => ({
                id: faker.datatype.uuid(),
                title: [
                  'Switched ON',
                  'Switched OFF',
                  'Switched ON',
                  'Switched OFF',
                  'Switched ON',
                ][index],
                type: `order${index + 1}`,
                time: faker.date.past(),
              }))}
            />
          </Grid>


        </Grid>
      </Container>
            :null}
    </Page>
  );
}
