import { faker } from '@faker-js/faker';
import { sample } from 'lodash';

// ----------------------------------------------------------------------

/* const users = [...Array(5)].map((_, index) => ({
  id: faker.datatype.uuid(),
  avatarUrl: `/static/mock-images/avatars/avatar_${index + 1}.jpg`,
  company: sample(['1', '2','3','4','5','6','7','8','9','10']),
  status: sample(['High', 'Low']),
  role: sample(['1350','2817','1263','2153','517','1623','763','825','1623','2218']),
}));

 */

const users = [
    {id:faker.datatype.uuid(),avatarUrl: null, company:"100",status:"High",role:"2350kWh"},
  {id:faker.datatype.uuid(),avatarUrl: null, company:"D102",status:"High",role:"2780kWh"},
  {id:faker.datatype.uuid(),avatarUrl: null, company:"101",status:"Low",role:"350kWh"},
  {id:faker.datatype.uuid(),avatarUrl: null, company:"114A",status:"High",role:"2230kWh"},
  {id:faker.datatype.uuid(),avatarUrl: null, company:"103",status:"Low",role:"750kWh"},
  {id:faker.datatype.uuid(),avatarUrl: null, company:"105",status:"Low",role:"530kWh"},
  {id:faker.datatype.uuid(),avatarUrl: null, company:"107",status:"High",role:"2350kWh"},



]

export default users;
