README

Webapp for Classroom building readings with AR

1.Download and Install Node.js
2.Run the command "npm install" to download the package and it's dependencies
3. Run the command "npm start" to start the application.